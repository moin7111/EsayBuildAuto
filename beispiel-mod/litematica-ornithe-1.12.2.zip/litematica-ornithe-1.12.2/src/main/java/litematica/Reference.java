package litematica;

import malilib.util.data.ModInfo;

public class Reference
{
    public static final String MOD_ID = "litematica";
    public static final String MOD_NAME = "Litematica";
    public static final String MOD_VERSION = "@MOD_VERSION@";

    public static final ModInfo MOD_INFO = new ModInfo(MOD_ID, MOD_NAME);
}
