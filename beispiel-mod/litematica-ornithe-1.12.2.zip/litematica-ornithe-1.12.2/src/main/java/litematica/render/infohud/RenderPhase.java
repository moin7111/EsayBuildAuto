package litematica.render.infohud;

public enum RenderPhase
{
    PRE,
    POST
}
